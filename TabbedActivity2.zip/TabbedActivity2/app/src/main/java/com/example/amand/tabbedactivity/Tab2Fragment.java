package com.example.amand.tabbedactivity;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import java.io.OutputStreamWriter;
import java.io.IOException;
import android.util.Log;

import java.io.PrintWriter;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

public class Tab2Fragment extends Fragment{

    private static final String TAG = "tab2fragment";

    Spinner CurrencySpinner1;
    String CurrencySpinner1TXT;
    EditText RateText;
    String RateTextTXT;
    Spinner CurrencySpinner2;
    String CurrencySpinner2TXT;
    EditText FuelCostText;
    String FuelCostTextTXT;
    Spinner CostSpinner;
    String CostSpinnerTXT;
    EditText FuelAmountText;
    String FuelAmountTextTXT;
    Spinner AmountSpinner;
    String AmountSpinnerTXT;
    EditText PreviousOdoText;
    String PreviousOdoTextTXT;
    EditText CurrentOdoText;
    String CurrentOdoTextTXT;
    Button CalculateButton;
   // String CalculateButtonTXT;
    Button LoadAndSaveButton;
    TextView LiterPerKmText;
    String LiterPerKmTextTXT;
    TextView SumText;
    String SumTextTXT;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState){

        final View view = inflater.inflate(R.layout.tab2,container,false);

        //Reference to all interactive items of the calculator

        CurrencySpinner1 = (Spinner) view.findViewById(R.id.CurrencySpinner1);
        RateText = (EditText) view.findViewById(R.id.RateText);
        CurrencySpinner2 = (Spinner) view.findViewById(R.id.CurrencySpinner2);
        FuelCostText = (EditText) view.findViewById(R.id.FuelCostText);
        CostSpinner= (Spinner) view.findViewById(R.id.CostSpinner);
        FuelAmountText = (EditText) view.findViewById(R.id.FuelAmountText);
        AmountSpinner = (Spinner) view.findViewById(R.id.AmountSpinner);
        PreviousOdoText = (EditText) view.findViewById(R.id.PreviousOdoText);
        CurrentOdoText = (EditText) view.findViewById(R.id.CurrentOdoText);
        CalculateButton = (Button) view.findViewById(R.id.CalculateButton);
        LoadAndSaveButton = (Button) view.findViewById(R.id.LoadAndSaveButton);
        LiterPerKmText = (TextView) view.findViewById(R.id.LiterPerKmText);
        SumText = (TextView) view.findViewById(R.id.SumText);


        //Events of Load and Save button click
        LoadAndSaveButton.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        //Check if the shared preferences file exists already
                        //Pull info and replace text in all fields
                    }
                }
        );
        //Events of the Calculate Button click
        CalculateButton.setOnClickListener(
         new View.OnClickListener() {
            @Override
             public void onClick(View v) {
                //Pulling the information from the labels
                CurrencySpinner1TXT = CurrencySpinner1.getSelectedItem().toString();
                RateTextTXT = RateText.getText().toString();
                CurrencySpinner2TXT = CurrencySpinner2.getSelectedItem().toString();
                FuelCostTextTXT =  FuelCostText.getText().toString();
                CostSpinnerTXT = CostSpinner.getSelectedItem().toString();
                FuelAmountTextTXT = FuelAmountText.getText().toString();
                AmountSpinnerTXT = AmountSpinner.getSelectedItem().toString();
                PreviousOdoTextTXT = PreviousOdoText.getText().toString();
                CurrentOdoTextTXT = CurrentOdoText.getText().toString();

                //Check if user filled out all fields and if so, display result
               try{
                    double RateTextTXTDbl = Double.parseDouble(RateTextTXT);
                    double  FuelCostTextTXTDbl = Double.parseDouble(FuelCostTextTXT);
                    double FuelAmountTextTXTDbl = Double.parseDouble(FuelAmountTextTXT);
                    int PreviousOdoTextTXTint = Integer.parseInt(PreviousOdoTextTXT);
                    int CurrentOdoTextTXTint = Integer.parseInt(CurrentOdoTextTXT);

                   Calculate data = new Calculate(CurrencySpinner1TXT,CurrencySpinner2TXT,
                           RateTextTXTDbl,CostSpinnerTXT,FuelCostTextTXTDbl,AmountSpinnerTXT,
                           FuelAmountTextTXTDbl,PreviousOdoTextTXTint,CurrentOdoTextTXTint);

                   LiterPerKmText.setText(String.valueOf(data.getFuelUsageInLitersPerKm(100)) + "L/100km");
                   SumText.setText("$" + String.valueOf(data.getTripPrice("CAD")) + " CAD");

                   //Save that data to shared preferences for LOAD LAST LOG button



                   //Pulling the date
                   DateFormat dateFormat = new SimpleDateFormat("dd/MM/YYYY/HH:mm");
                   Date date = new Date();
                   System.out.println(dateFormat.format(date)); //2016/11/16/12:08:43

                   //Writing to log file //fix new line
                   String calcInfoToWrite = "> " + dateFormat.format(date) + " , " + String.valueOf(data.getFuelUsageInLitersPerKm(100)) + "L/100km" + " , "
                           + String.valueOf(data.getTripPrice("CAD")) + " CAD" + " , " + "Last odo: " + data.getLastOdo();

                   FileActions fileAct0 = new FileActions();
                   fileAct0.writeToFile(calcInfoToWrite,view.getContext());

                }
                catch(Exception e)
               {
                    Toast.makeText(getActivity(), "Make sure you entered numerical values in fields",
                            Toast.LENGTH_SHORT).show();
               }
            }
        });
        return view;
    }
}
