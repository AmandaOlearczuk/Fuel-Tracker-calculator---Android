package com.example.amand.tabbedactivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.text.Html;
import android.widget.Button;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.content.Context;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Tab3Fragment extends Fragment {

    private static final String TAG = "tab3fragment";

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        final View view = inflater.inflate(R.layout.tab3, container, false);

        Button RefreshButton = (Button) view.findViewById(R.id.RefreshButton);
        Button DeleteLogsButton = (Button) view.findViewById(R.id.DeleteLogs);

        final FileActions fileAct1 = new FileActions();

        //Events of the Refresh Button click
        RefreshButton.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        //pull info from file and display in textField
                        TextView LogTextField = (TextView) view.findViewById(R.id.TripLog);

                        LogTextField.setText(Html.fromHtml(fileAct1.readFromFile(view.getContext())));

                    }
                });

        //Events of Delete Logs button
        DeleteLogsButton.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        //Display a conformation window
                        AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());
                        builder.setMessage("Delete all trip logs?").setPositiveButton("Delete All", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                fileAct1.deleteFileContents(view.getContext());
                                Toast.makeText(getActivity(), "Trip Logs Deleted - Refresh log",
                                        Toast.LENGTH_SHORT).show();
                            }
                        }).setNegativeButton("Cancel",null).setNeutralButton("Delete Last log", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                                //Delete last line from file
                              boolean deleteLastLineSuccessORFailure = fileAct1.deleteLastLine(view.getContext());
                              if (deleteLastLineSuccessORFailure == true)
                              {
                                  Toast.makeText(getActivity(), "Last log deleted - Refresh log" ,Toast.LENGTH_SHORT).show();
                              }
                              else
                              {
                                  Toast.makeText(getActivity(), "There is no saved logs" ,Toast.LENGTH_SHORT).show();
                              }

                                }
                        });

                        AlertDialog alert = builder.create();
                        alert.show();

                    }
                });
        //write to file from the info we got
        return view;
    }

    }

