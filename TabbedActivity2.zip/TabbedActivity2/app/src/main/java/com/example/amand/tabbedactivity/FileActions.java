package com.example.amand.tabbedactivity;

import android.content.Context;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Arrays;

/**
 * FileActions class is responsible for manipulating the file data as deleting,writing,reading,
 * for "TruckerFuelCalculator CAD/USD"
 * @author Amanda Olearczuk
 *
 */

public class FileActions {

    /**
     * This method writes a string to TripLog.txt ,line by line
     * @param someData - String
     * @param context
     * @return true or false - success or failure to delete the contents
     */
    protected boolean writeToFile(String someData, Context context) {
        try {
            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(context.openFileOutput("TripLog.txt",Context.MODE_APPEND));
            //outputStreamWriter.write("<br/>"); //line break before
            outputStreamWriter.write(someData);    //add line of text
            outputStreamWriter.write("<br/>"); //line break after
            outputStreamWriter.close();

            return true;
           // Toast.makeText(getActivity(), "Saving data successful",Toast.LENGTH_SHORT).show();

        }
        catch (IOException e) {
           // Toast.makeText(getActivity(), "Saving data failed",Toast.LENGTH_SHORT).show();
            return false;
        }

    }

    /**
     * This method delets file contents from Triplog.txt
     *@param context
     * @return true or false - success or failure to delete the contents
     */
    protected boolean deleteFileContents(Context context){
        try
        {
            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(context.openFileOutput("TripLog.txt",Context.MODE_PRIVATE));
            outputStreamWriter.write("");    //add line of text
            outputStreamWriter.close();

            return true;
           // Toast.makeText(getActivity(), "Trip Log Deleted", Toast.LENGTH_SHORT).show();
        }
        catch (IOException e)
        {
            return false;
           // Toast.makeText(getActivity(), "Trip Log FAILED to delete", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * This method deletes last log from TripLog.txt
     * @param context
     * @return true or false - success or failure to delete the last line OR does line exist or not
     */
    protected boolean deleteLastLine(Context context){

        //Read file contents
        String fileContents =  this.readFromFile(context);

        //Check if file isn't empty
        if (fileContents.equals(""))
        {
            return false;
            //Toast.makeText(getActivity(), "There is no saved logs" ,Toast.LENGTH_SHORT).show();
        }

        else
        {
            ArrayList<String> logsAsList = new ArrayList<>(Arrays.asList(fileContents.split("<br/>")));

            // Remove last entry if it in fact exists
            int logsAsListSize = logsAsList.size();

            try //Do this if log isn't empty
            {
                logsAsList.remove(logsAsListSize - 1);
                //Join list to 1 String
                String writeThis =  android.text.TextUtils.join("<br/>", logsAsList);

                //Write to file and display message

                boolean deleteFileContentsSuccessOrFail = this.deleteFileContents(context);

                if (deleteFileContentsSuccessOrFail == true)
                {
                    boolean successORfailure = this.writeToFile(writeThis, context);
                    if (successORfailure == true) {
                        return true;
                       /// Toast.makeText(getActivity(), "Saving data successful - Refresh Log", Toast.LENGTH_SHORT).show();
                    } else {
                        return false;
                       // Toast.makeText(getActivity(), "Saving data failed", Toast.LENGTH_SHORT).show();
                    }
                }
                else
                {
                    return false;
                    //Toast.makeText(getActivity(), "Saving data failed", Toast.LENGTH_SHORT).show();
                }
            }


            catch(ArrayIndexOutOfBoundsException e)  //Do this if the log is empty
            {
                return false;
               // Toast.makeText(getActivity(), "There is no saved logs", Toast.LENGTH_SHORT).show();

            }
        }



    }
    /**
     * This method reads from TripLog.txt
     * @param context
     * @return content - Which is a String
     */
    protected String readFromFile(Context context) { //Doesn't work - File not found exeption

        String content = "";

        try {
            InputStream inputStream = context.openFileInput("TripLog.txt");
           // Toast.makeText(getActivity(), "Refresh Successful",Toast.LENGTH_SHORT).show();
            if (inputStream != null) {
                InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                String receiveString = "";
                StringBuilder stringBuilder = new StringBuilder();

                while ((receiveString = bufferedReader.readLine()) != null) {
                    stringBuilder.append(receiveString);
                }

                inputStream.close();
                content = stringBuilder.toString();


            }
        } catch (FileNotFoundException e) {
            //Toast.makeText(getActivity(), "Failed to read Trip Log",Toast.LENGTH_SHORT).show();

        } catch (IOException e) {
           // Toast.makeText(getActivity(), "Failed to read Trip Log",Toast.LENGTH_SHORT).show();
        }

        return content;
    }
}
