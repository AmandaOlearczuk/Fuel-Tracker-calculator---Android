package com.example.amand.tabbedactivity;

/**
 * Calculate class is responsible for manipulating the data and calculating the result
 * of the fuel and prices for "TruckerFuelCalculator CAD/USD"
 * @author Amanda Olearczuk
 *
 */
import java.text.DecimalFormat;

public class Calculate {

    private String fromCurrency = " ";
    private String toCurrency = " ";
    private double currencyRate = 0.00;
    private String fuelPriceUnit = " ";
    private double fuelPrice = 0.00;
    private String fuelUsedUnit =" ";
    private double fuelUsed = 0.00;
    private int previousOdo = 0;
    private int currentOdo = 0;

    /**
     * This is a constructor for the class
     * @param fromCurrency
     * @param toCurrency
     * @param currencyRate
     * @param fuelPriceUnit
     * @param fuelPrice
     * @param previousOdo
     * @param currentOdo
     */
    public Calculate(String fromCurrency, String toCurrency,
                     double currencyRate, String fuelPriceUnit,
                     double fuelPrice,String fuelUsedUnit,double fuelUsed, int previousOdo, int currentOdo) {

        this.fromCurrency = fromCurrency;
        this.toCurrency = toCurrency;
        this.currencyRate = currencyRate;
        this.fuelPriceUnit = fuelPriceUnit;
        this.fuelPrice = fuelPrice;
        this.fuelUsedUnit = fuelUsedUnit;
        this.fuelUsed = fuelUsed;
        this.previousOdo = previousOdo;
        this.currentOdo = currentOdo;
    }

    /**
     * This method is a getter for the last Odo entered, also preventing privacy leak
     * @return currentOdo - integer
     */
    public int getLastOdo(){
        return new Integer(this.currentOdo);
    }
    /**
     * This method calculates how many kilometers were driven
     * @return int - kilometers driven
     */
    public int getKilometersDriven()
    {
        return (this.currentOdo - this.previousOdo);
    }

    /**
     * This method returns 1CAD = x USD rate
     * @return double - x USD
     */
    public double get1CADtoUSDRate() {

        double CadToUsdRate;

        //If input goes from 1USD = ...CAD
        if(fromCurrency.equals("1 USD"))
        {
            CadToUsdRate = (double)1/(double)currencyRate;
            return CadToUsdRate;
        }

        else
        {
            return currencyRate;
        }
    }

    /**
     * This method returns 1USD = x CAD rate
     * @return double - x CAD
     */
    public double get1USDtoCADRate()
    {
        double UsdToCadRate = 0.00;

        //If input goes from 1CAD = ...USD
        if(fromCurrency.equals("1 CAD"))
        {
            UsdToCadRate = (double)1/(double)currencyRate;
            return UsdToCadRate;
        }

        else
        {
            return currencyRate;
        }
    }

    /**
     * This method returns LITERS of fuel used on a trip
     * @return double - Liters
     */
    public double getLitersUsed()
    {
        if(fuelUsedUnit.equals("Gal"))
        {
            return (fuelUsed * 3.78541);
        }

        else
        {
            return fuelUsed;
        }
    }

    /**
     * This method returns price of fuel in Cad/1 liter
     * @return double - Cad/1 liter
     */
    public double calculatePriceCADperLiter()
    {
        if(fuelPriceUnit.equals("USD/Gal"))
        {
            return ((fuelPrice * get1USDtoCADRate())/(double)3.78541);
        }

        else
        {
            return fuelPrice;
        }

    }

    /**
     * This method returns price of fuel in Cad/ x liter
     * @return double - Cad/x liter
     */
    public double calculatePriceCADperLiter(Double literAmount)
    {
        return (calculatePriceCADperLiter() * literAmount);
    }

    /**
     * USER SEES THIS RESULT
     * This method calculates total trip price in CAD
     * @return double - 2 decimal places
     */
    public double getTripPrice(String currency)
    {
        double result;

        if(currency.equals("CAD"))
        {
            result = getLitersUsed() * calculatePriceCADperLiter();
            return (Double.parseDouble(new DecimalFormat("##.##").format(result)));
        }
        else
        {
            result = (getLitersUsed() * calculatePriceCADperLiter()) * get1CADtoUSDRate();
            return (Double.parseDouble(new DecimalFormat("##.##").format(result)));
        }
    }

    /**
     * USER SEES THIS RESULT
     * This method returns fuel consumption per desired amount of km
     * @param kilometers
     * @return int - in L/desired amount of km - 3 decimal places
    */
    public int getFuelUsageInLitersPerKm(int kilometers) {
        int result = (int)((getLitersUsed()/getKilometersDriven()) * kilometers);
        return (result);
    }



}

